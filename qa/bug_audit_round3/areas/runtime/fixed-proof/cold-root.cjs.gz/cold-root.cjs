'use strict';
const {createRequire,Module}=require('node:module');
const {readFileSync,writeFileSync}=require('node:fs');
const {resolve,dirname}=require('node:path');
const assert=require('node:assert/strict');
const {isDeepStrictEqual}=require('node:util');
const test=require('node:test');
const {createHash}=require('node:crypto');
const req=createRequire('/workspace/luno-chess/functions/package.json');
const namespace='demo-luno-cold-root-r3-default-rtdb';
assert.equal(process.env.FIREBASE_DATABASE_EMULATOR_HOST,'127.0.0.1:19000');
assert.equal(process.env.LUNO_DB_EMULATOR_NAMESPACE,namespace);
assert.equal(process.env.GCLOUD_PROJECT,'demo-luno-cold-root-r3');
assert.equal(process.env.GOOGLE_APPLICATION_CREDENTIALS,undefined);
assert.equal(process.env.FIREBASE_AUTH_EMULATOR_HOST,undefined);

// The Admin SDK embeds its own websocket client inside database-compat/standalone.
// Compile exactly one transport-condition change in memory. SDK files and all
// database data/transaction logic remain byte-identical on disk and in memory.
const standalonePath=req.resolve('@firebase/database-compat/standalone');
assert.equal(require.cache[standalonePath],undefined);
const standaloneOriginal=readFileSync(standalonePath,'utf8');
const transportNeedle="if (proxy) {\n                    options['proxy'] = { origin: proxy };\n                }";
assert.equal(standaloneOriginal.split(transportNeedle).length-1,1);
const transportAudit={selected_connections:0,rejected_other_urls:0,headers_or_proxy_environment_changed:false,smoke_pass:false};
const proxyKeys=['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy','NO_PROXY','no_proxy'];
const inheritedProxyValues=Object.fromEntries(proxyKeys.map(key=>[key,process.env[key]]));
assert.ok(process.env.HTTP_PROXY||process.env.http_proxy,'This proof diagnoses the inherited-proxy path.');
function saveAudit(){transportAudit.inherited_proxy_environment_unchanged=proxyKeys.every(key=>process.env[key]===inheritedProxyValues[key]);writeFileSync(resolve(dirname(__filename),'transport-audit.json'),JSON.stringify(transportAudit,null,2)+'\n');}
globalThis.__LUNO_PROOF_LOOPBACK__=url=>{
 const parsed=new URL(url);
 if(parsed.protocol!=='ws:'||parsed.hostname!=='127.0.0.1'||parsed.port!=='19000'||parsed.pathname!=='/.ws'||parsed.searchParams.get('ns')!==namespace||parsed.username||parsed.password){transportAudit.rejected_other_urls++;saveAudit();throw new Error('Proof refuses a non-local emulator socket.');}
 transportAudit.selected_connections++;saveAudit();return true;
};
const standalonePatched=standaloneOriginal.replace(transportNeedle,transportNeedle.replace('if (proxy)', 'if (proxy && !globalThis.__LUNO_PROOF_LOOPBACK__(this.connURL))'));
const standaloneModule=new Module(standalonePath,module);standaloneModule.filename=standalonePath;standaloneModule.paths=Module._nodeModulePaths(dirname(standalonePath));require.cache[standalonePath]=standaloneModule;standaloneModule._compile(standalonePatched,standalonePath);standaloneModule.loaded=true;
const transportProvenance={standalone_module:standalonePath,original_sha256:createHash('sha256').update(standaloneOriginal).digest('hex'),in_memory_sha256:createHash('sha256').update(standalonePatched).digest('hex'),exact_replaced_blocks:1,changed_transport_condition_only:true,repo_or_sdk_disk_files_modified:false};
writeFileSync(resolve(dirname(__filename),'transport-provenance.json'),JSON.stringify(transportProvenance,null,2)+'\n');

const root=dirname(__filename),original='/workspace/luno-chess/functions/lib/battle-v1-friendly.js';
const captured=readFileSync(resolve(root,'captured-friendly.cjs'),'utf8');
const sourceTarget=JSON.parse(readFileSync(resolve(root,'source-target.json'),'utf8'));
assert.equal(createHash('sha256').update(captured).digest('hex'),sourceTarget.friendly_sha256);
const backend=new Module(original,module);backend.filename=original;
backend.paths=Module._nodeModulePaths(dirname(original));backend._compile(captured,original);
const {installBattleV1Friendly}=backend.exports;
const {initializeApp,deleteApp,getApps}=req('firebase-admin/app');
const {getDatabase}=req('firebase-admin/database');
const projectId='demo-luno-cold-root-r3',databaseURL='http://127.0.0.1:19000?ns='+namespace;
const checkerApp=initializeApp({projectId,databaseURL},'round3-independent-seed-and-check');
const checker=getDatabase(checkerApp),observations=[];
const at=1750000000000,sender='runtime_sender',guest='runtime_guest',inviteKey=sender+'|'+guest;
const fixture={battleV1Control:{invites:{[inviteKey]:{from:{uid:sender,player:{name:'Sender'}},to:guest,requestId:'original-invite',expiresAt:at+120000}}},matchInvites:{[guest]:{[sender]:{status:'pending'}}},unrelated:{preserved:7}};
const context={uid:guest,requestId:'decline-request',body:{client:{},fromUid:sender,accept:false}};
function record(value){if(value.trace)value.transaction_committed=value.trace.committed;observations.push(value);writeFileSync(resolve(root,'observations.json'),JSON.stringify(observations,null,2)+'\n');}
function freshDb(name){return getDatabase(initializeApp({projectId,databaseURL},name));}
function proxied(target,methods){return new Proxy(target,{get(node,key){if(Object.hasOwn(methods,key))return methods[key];const v=Reflect.get(node,key,node);return typeof v==='function'?v.bind(node):v;}});}
function traceDb(db,trace){
 return proxied(db,{ref(...refArgs){
  const ref=db.ref(...refArgs);
  return proxied(ref,{async transaction(update,onComplete,applyLocally){
   const tx=await ref.transaction(value=>{
    const step={input_null:value===null,invite_present:!!value?.invites?.[inviteKey]};trace.push(step);
    const returned=update(value);step.output_undefined=returned===undefined;step.output_null=returned===null;return returned;
   },onComplete,applyLocally);
   trace.committed=tx.committed;return tx;
  }});
 }});
}
function friendly(db,trace){
 const api={db:traceDb(db,trace),now:()=>at,admission:async()=>{},entry:async uid=>({uid,player:{name:uid}})};
 const deps={requirePlayer:async()=>({}),rateLimit:async()=>{},withSocialPairLock:async(a,b,run)=>run(),assertInteractionAllowed:async()=>{},requireFriendship:async()=>{}};
 return installBattleV1Friendly(api,deps);
}
async function seed(){await checker.ref().set(fixture);assert.deepEqual((await checker.ref().get()).val(),fixture);}
test.before(async()=>{
 let timer;
 try{await Promise.race([(async()=>{await checker.ref('sdkSmoke').set({value:7});assert.equal((await checker.ref('sdkSmoke/value').get()).val(),7);await checker.ref('sdkSmoke').remove();})(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('3s SDK seed/read smoke timeout.')),3000);})]);transportAudit.smoke_pass=true;saveAudit();}
 finally{clearTimeout(timer);}
});
test.after(async()=>{await Promise.all(getApps().map(deleteApp));saveAudit();assert.equal(transportAudit.inherited_proxy_environment_unchanged,true);assert.equal(createHash('sha256').update(readFileSync(standalonePath)).digest('hex'),transportProvenance.original_sha256);});

test('real SDK control: cold null no-op retries against existing remote root',{timeout:5000},async()=>{
 await seed();const db=freshDb('round3-raw-cold'),trace=[];
 const tx=await traceDb(db,trace).ref('battleV1Control').transaction(value=>{
  if(value===null)return null;
  delete value.invites[inviteKey];return value;
 },undefined,false);
 const durable=(await checker.ref().get()).val();
 record({case:'raw-sdk-cold-null-cas-retry',trace,committed:tx.committed,durable});
 assert.equal(trace[0].input_null,true);assert.equal(trace[0].output_null,true);
 assert.ok(trace.some(step=>step.invite_present));assert.equal(tx.committed,true);
 assert.equal(durable.battleV1Control,undefined);assert.equal(durable.unrelated.preserved,7);
});

test('captured source: cold existing valid invite decline succeeds',{timeout:5000},async()=>{
 await seed();const db=freshDb('round3-friendly-cold'),trace=[];
 const api=friendly(db,trace);let result,error;
 try{result=await api.respondBattleV1Invite(context);}catch(e){error={name:e.name,code:e.code,status:e.status};}
 const durable=(await checker.ref().get()).val();
 record({case:'friendly-cold-existing-invite',seed_root_verified:true,tested_app_reads_before_transaction:0,trace,result,error,durable,root_unchanged:isDeepStrictEqual(durable,fixture)});
 assert.equal(error,undefined,'Valid existing invite must not be rejected from the SDK initial null cache.');
 assert.deepEqual(result,{ok:true,accepted:false});assert.equal(durable.battleV1Control,undefined);assert.equal(durable.matchInvites,undefined);
});

test('captured source control: same invite with warm root declines successfully',{timeout:5000},async()=>{
 await seed();const db=freshDb('round3-friendly-warm'),trace=[];
 const ref=db.ref('battleV1Control');let listener;
 await new Promise((resolve,reject)=>{listener=value=>{if(value.val()?.invites?.[inviteKey])resolve();};ref.on('value',listener,reject);});
 try{
  const result=await friendly(db,trace).respondBattleV1Invite(context),durable=(await checker.ref().get()).val();
  record({case:'friendly-warm-existing-invite',same_seed_as_cold:true,trace,result,durable});
  assert.equal(trace[0].invite_present,true);assert.deepEqual(result,{ok:true,accepted:false});
  assert.equal(durable.battleV1Control,undefined);assert.equal(durable.matchInvites,undefined);assert.equal(durable.unrelated.preserved,7);
 }finally{ref.off('value',listener);}
});

test('captured source control: independently verified empty database returns invite 404',{timeout:5000},async()=>{
 await checker.ref().set(null);assert.equal((await checker.ref().get()).val(),null);
 const db=freshDb('round3-friendly-empty'),trace=[];let error;
 try{await friendly(db,trace).respondBattleV1Invite(context);}catch(e){error={code:e.code,status:e.status};}
 const durable=(await checker.ref().get()).val();
 record({case:'friendly-truly-empty-root',independent_seed_root:null,trace,error,durable});
 assert.deepEqual(error,{code:'INVITE_UNAVAILABLE',status:404});assert.equal(durable,null);
});

